"""Sidebar section builder and renderer.

Layout mirrors the VS Code Debug sidebar:
  ▼ 󰓦  GOROUTINES  2        ← compact header with icon + count badge
    ▶  goroutine 1
    ▶  goroutine 2           ← thin divider (virtual line)
  ▼ 󰫧  VARIABLES            ← collapsed / expanded toggle
  ▼ 󰆼  CALL STACK   3
  ▼ 󰝥  BREAKPOINTS  1
  ▼ 󰈈  WATCHES

Rendering is fully atomic (modifiable toggled once), uses a single
extmark namespace per buffer, and never recreates the buffer.
"""

from __future__ import annotations
import os
from typing import Optional
import pynvim
from .highlights import ICON

# ── config ────────────────────────────────────────────────────────────────────
CFG = {
    "sidebar_min_width": 34,
    "sidebar_pct": 0.21,
    "max_val_len": 52,
    "max_watch_len": 40,
    "sep_char": "─",
}

# Ordered section definitions: (id, icon, display title)
SECTIONS = [
    ("goroutines", ICON["goroutines"], "GOROUTINES"),
    ("variables", ICON["variables"], "VARIABLES"),
    ("stack", ICON["stack"], "CALL STACK"),
    ("breakpoints", ICON["breakpoints"], "BREAKPOINTS"),
    ("watches", ICON["watches"], "WATCHES"),
]

# Namespace name used for all extmarks in the sidebar buffer.
_NS = "go_dbg_sidebar"


# ── helpers ───────────────────────────────────────────────────────────────────


def sb_width(nvim: pynvim.Nvim) -> int:
    cols = nvim.options["columns"]
    return max(CFG["sidebar_min_width"], int(cols * CFG["sidebar_pct"]))


def _truncate(s: str, max_len: int) -> str:
    return s if len(s) <= max_len else s[: max_len - 1] + "…"


def _shrt(path: str) -> str:
    """Return path relative to cwd or home, thread-safe."""
    if not path:
        return "?"
    try:
        p = path.replace("\\", "/")
        cwd = os.getcwd().replace("\\", "/")
        if p.startswith(cwd):
            return p[len(cwd) :].lstrip("/") or path
        home = os.path.expanduser("~").replace("\\", "/")
        if p.startswith(home):
            return "~/" + p[len(home) :].lstrip("/")
    except Exception:
        pass
    return path


def _val_hl(v: str) -> str:
    """Return the highlight group name appropriate for value string v."""
    if v in ("nil", "<nil>"):
        return "GoDbgVarNil"
    if v in ("true", "false"):
        return "GoDbgVarBool"
    if v.startswith("0x"):
        return "GoDbgVarPtr"
    if v and v[0] in ('"', "`"):
        return "GoDbgVarStr"
    if v and (v[0].isdigit() or (v[0] == "-" and len(v) > 1 and v[1].isdigit())):
        return "GoDbgVarVal"
    return "GoDbgVarName"


# ── item builders ─────────────────────────────────────────────────────────────


def build_goroutine_items(threads: list, active_tid: Optional[int]) -> tuple[list, int]:
    items = []
    for t in threads:
        active = t.get("id") == active_tid
        bullet = ICON["exec_arrow"] if active else "·"
        label = t.get("name") or f"goroutine {t.get('id', '?')}"
        text = f"  {bullet}  {label}"
        grp = "GoDbgActive" if active else "GoDbgFrameInact"
        items.append(
            {
                "text": text,
                "hls": [
                    {"c0": 2, "c1": 2 + len(bullet), "grp": grp},
                    {"c0": 2 + len(bullet) + 2, "c1": len(text), "grp": grp},
                ],
            }
        )
    return items, len(threads)


def build_variable_items(
    scopes: list,
    vars_by_scope: dict,
    var_nodes: dict,
    width: int,
) -> tuple[list, int]:
    items = []
    total = 0
    name_w = max(12, min(18, width - 18))

    def _add_recursive(vars_list: list, depth: int):
        nonlocal total
        for v in vars_list:
            total += 1
            name = str(v.get("name") or "?")
            val = _truncate(str(v.get("value") or ""), CFG["max_val_len"] - (depth * 2))
            typ = str(v.get("type") or "")
            ref = v.get("variablesReference", 0)
            has_ch = ref > 0

            indent = "  " * (depth + 2)
            if has_ch:
                node = var_nodes.get(ref)
                exp = node.expanded if node else False
                tog = ICON["tree_open"] if exp else ICON["tree_closed"]
                pfx = f"{indent}{tog} "
            else:
                pfx = f"{indent}  "

            np = f"{name:<{max(8, name_w - depth * 2)}}"
            text = f"{pfx}{np}  {val}"
            
            c0n = len(pfx)
            c1n = c0n + len(np)
            c0e = c1n
            c1e = c0e + 2
            c0v = c1e

            item = {
                "text": text,
                "hls": [
                    {"c0": c0n, "c1": c1n, "grp": "GoDbgVarName"},
                    {"c0": c0e, "c1": c1e, "grp": "GoDbgVarEq"},
                    {"c0": c0v, "c1": len(text), "grp": _val_hl(val)},
                ],
                "meta": {"type": "variable", "vref": ref, "name": name}
            }
            if typ:
                item["virt"] = typ
            items.append(item)

            if has_ch:
                node = var_nodes.get(ref)
                if node and node.expanded and node.children:
                    _add_recursive(node.children, depth + 1)

    for scope in scopes:
        sname = scope.get("name", "scope")
        hdr = f"  {ICON['scope']}  {sname}"
        items.append(
            {
                "text": hdr,
                "hls": [
                    {"c0": 2, "c1": 2 + len(ICON["scope"]), "grp": "GoDbgSectionIcon"},
                    {
                        "c0": 4 + len(ICON["scope"]),
                        "c1": len(hdr),
                        "grp": "GoDbgScopeName",
                    },
                ],
                "meta": {"type": "scope", "name": sname}
            }
        )
        ref = scope.get("variablesReference", 0)
        _add_recursive(vars_by_scope.get(ref) or [], 0)

    return items, total


def build_stack_items(frames: list) -> tuple[list, int]:
    items = []
    for i, frame in enumerate(frames):
        active = i == 0
        name = frame.get("name") or f"frame {i + 1}"
        src = (frame.get("source") or {}).get("path") or ""
        lnum = frame.get("line")
        addr = frame.get("instructionPointerReference")
        fid = frame.get("id")
        arrow = ICON["exec_arrow"] if active else " "
        idx = f"{i + 1:2d}"

        row1 = f"  {arrow} {idx}  {name}"
        items.append(
            {
                "text": row1,
                "hls": [
                    {
                        "c0": 2,
                        "c1": 2 + len(arrow),
                        "grp": "GoDbgFrameArrow" if active else "GoDbgFrameInact",
                    },
                    {"c0": 3, "c1": 3 + len(idx), "grp": "GoDbgFrameIdx"},
                    {
                        "c0": 3 + len(idx) + 2,
                        "c1": len(row1),
                        "grp": "GoDbgFrameActive" if active else "GoDbgFrameInact",
                    },
                ],
                "virt": f"@ {addr}" if addr else None,
                "meta": {"type": "stack_frame", "fid": fid, "file": src, "line": lnum}
            }
        )
        if src:
            row2 = "        " + _shrt(src) + ":" + str(lnum or "?")
            items.append(
                {
                    "text": row2,
                    "hls": [{"c0": 0, "c1": len(row2), "grp": "GoDbgFrameFile"}],
                    "meta": {"type": "stack_frame", "fid": fid, "file": src, "line": lnum}
                }
            )
    return items, len(frames)


def build_bp_items(bps: list) -> tuple[list, int]:
    items = []
    for bp in bps:
        if bp.log_message:
            icon, ihl = ICON["bp_log"], "GoDbgBPIconLog"
        elif bp.condition:
            icon, ihl = ICON["bp_cond"], "GoDbgBPIconCond"
        else:
            icon, ihl = ICON["bp_normal"], "GoDbgBPIcon"

        f = _shrt(bp.file)
        lnum = str(bp.line)
        text = f"  {icon}  {f}:{lnum}"
        ci = 2
        cf = ci + len(icon) + 2
        cl = cf + len(f) + 1

        items.append(
            {
                "text": text,
                "hls": [
                    {"c0": ci, "c1": ci + len(icon), "grp": ihl},
                    {"c0": cf, "c1": cf + len(f), "grp": "GoDbgBPFile"},
                    {"c0": cl, "c1": len(text), "grp": "GoDbgBPLnum"},
                ],
                "meta": {"type": "breakpoint", "file": bp.file, "line": bp.line}
            }
        )

        if bp.condition:
            ct = f"     if {bp.condition}"
            items.append(
                {
                    "text": ct,
                    "hls": [{"c0": 0, "c1": len(ct), "grp": "GoDbgBPCond"}],
                    "meta": {"type": "breakpoint", "file": bp.file, "line": bp.line}
                }
            )
        elif bp.log_message:
            lt = f"     {ICON['output']} {bp.log_message}"
            items.append(
                {
                    "text": lt,
                    "hls": [{"c0": 0, "c1": len(lt), "grp": "GoDbgBPCond"}],
                    "meta": {"type": "breakpoint", "file": bp.file, "line": bp.line}
                }
            )
    return items, len(bps)


def build_watch_items(watches: list, width: int) -> tuple[list, int]:
    items = []
    if not watches:
        t = "   no watches"
        items.append({
            "text": t, 
            "hls": [{"c0": 3, "c1": len(t), "grp": "GoDbgEmpty"}],
            "meta": {"type": "empty"}
        })
        return items, 0

    expr_w = max(14, min(20, width - 14))
    for w in watches:
        val = _truncate(str(w.get("value") or "…"), CFG["max_watch_len"])
        pad = f"  {w['expr']:<{expr_w}}"
        text = f"{pad}  {val}"
        grp = "GoDbgOutErr" if w.get("error") else _val_hl(val)
        items.append(
            {
                "text": text,
                "hls": [
                    {"c0": 0, "c1": len(pad), "grp": "GoDbgVarName"},
                    {"c0": len(pad), "c1": len(pad) + 2, "grp": "GoDbgVarEq"},
                    {"c0": len(pad) + 2, "c1": len(text), "grp": grp},
                ],
                "meta": {"type": "watch", "expr": w["expr"]}
            }
        )
    return items, len(watches)



# ── renderer ──────────────────────────────────────────────────────────────────


def render_sidebar(nvim: pynvim.Nvim, state) -> None:
    """Atomically write lines + extmarks to the sidebar buffer."""
    ui = state.ui
    buf = ui.sidebar_buf
    if not buf or not nvim.api.buf_is_valid(buf):
        return

    ns = nvim.api.create_namespace(_NS)
    w = sb_width(nvim)

    lines: list[str] = []
    hls: list[tuple] = []  # (row, c0, c1, grp)
    virts: list[tuple] = []  # (row, text)
    hdrs: list[int] = []  # rows that get GoDbgHeader line-hl
    div_rows: list[int] = []  # rows *after* which a divider appears
    sec_rows: dict[int, str] = {}  # 0-based row → section_id
    row_map: dict[int, dict] = {} # 0-based row -> metadata

    def add_hl(r: int, c0: int, c1: int, grp: str) -> None:
        if c1 > c0:
            hls.append((r, c0, c1, grp))

    for si, (sec_id, sec_icon, sec_title) in enumerate(SECTIONS):
        sec = ui.sections[sec_id]
        row0 = len(lines)

        # ── section header ────────────────────────────────────────────────
        tog = ICON["tree_open"] if not sec.collapsed else ICON["tree_closed"]
        cnt = f"  {sec.count}" if sec.count is not None else ""
        # e.g. "▼ 󰓦  GOROUTINES  2"
        hdr = f" {tog} {sec_icon}  {sec_title}{cnt}"

        lines.append(hdr)
        sec_rows[row0] = sec_id
        row_map[row0] = {"type": "section_header", "section_id": sec_id}
        hdrs.append(row0)

        col = 1
        add_hl(row0, col, col + len(tog), "GoDbgCollapse")
        col += len(tog) + 1
        add_hl(row0, col, col + len(sec_icon), "GoDbgSectionIcon")
        col += len(sec_icon) + 2
        add_hl(row0, col, col + len(sec_title), "GoDbgSectionHdr")
        col += len(sec_title)
        if sec.count is not None:
            add_hl(row0, col, len(hdr), "GoDbgSectionCnt")

        # ── section body ─────────────────────────────────────────────────
        if not sec.collapsed:
            its = sec.items or []
            if not its:
                r = len(lines)
                et = "   —"
                lines.append(et)
                row_map[r] = {"type": "empty", "section_id": sec_id}
                add_hl(r, 0, len(et), "GoDbgEmpty")
            else:
                for item in its:
                    r = len(lines)
                    lines.append(item["text"])
                    row_map[r] = item.get("meta") or {"type": "item", "section_id": sec_id}
                    for h in item.get("hls") or []:
                        add_hl(r, h["c0"], h["c1"], h["grp"])
                    if item.get("virt"):
                        virts.append((r, item["virt"]))

        # thin divider between sections (not after the last one)
        if si < len(SECTIONS) - 1:
            div_rows.append(len(lines) - 1)

    # ── atomic buffer write ───────────────────────────────────────────────
    try:
        try:
            nvim.api.set_option_value("modifiable", True, {"buf": buf})
            nvim.api.buf_set_lines(buf, 0, -1, False, lines)
            nvim.api.buf_clear_namespace(buf, ns, 0, -1)

            # inline highlights
            for r, c0, c1, grp in hls:
                try:
                    nvim.api.buf_set_extmark(
                        buf,
                        ns,
                        r,
                        c0,
                        {
                            "end_col": c1,
                            "hl_group": grp,
                            "priority": 10,
                        },
                    )
                except Exception:
                    pass

            # right-aligned type hints
            for r, vtext in virts:
                try:
                    nvim.api.buf_set_extmark(
                        buf,
                        ns,
                        r,
                        0,
                        {
                            "virt_text": [[vtext, "GoDbgVarType"]],
                            "virt_text_pos": "right_align",
                            "priority": 5,
                        },
                    )
                except Exception:
                    pass

            # single-pixel virtual-line dividers between sections
            sep = [["─" * w, "GoDbgDivider"]]
            for dr in div_rows:
                try:
                    nvim.api.buf_set_extmark(
                        buf,
                        ns,
                        dr,
                        0,
                        {
                            "virt_lines": [sep],
                            "virt_lines_above": False,
                            "priority": 1,
                        },
                    )
                except Exception:
                    pass

            # header row background
            for hrow in hdrs:
                try:
                    nvim.api.buf_set_extmark(
                        buf,
                        ns,
                        hrow,
                        0,
                        {
                            "line_hl_group": "GoDbgHeader",
                            "priority": 1,
                        },
                    )
                except Exception:
                    pass
        except Exception:
            return

    finally:
        try:
            nvim.api.set_option_value("modifiable", False, {"buf": buf})
        except Exception:
            pass

    ui.sec_rows = sec_rows
    ui.row_map = row_map
